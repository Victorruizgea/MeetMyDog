package com.ucm.meetmydog;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class InicioSesionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion);
    }
}